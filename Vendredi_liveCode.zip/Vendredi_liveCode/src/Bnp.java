import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.ListIterator;


public class Bnp {

	String nameBank;
	int IdBank;
	Hashtable name = new Hashtable();
	
	 public Bnp(){
		 
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

Bnp instance = new Bnp();
		
		instance.name.put("Gwen", 635268595);
		instance.name.put("Jenny", 658963215);
		instance.name.put("Amina", 698751452);
		instance.name.put("Hayat", 698321574);
		instance.name.put("Julien", 698532154);
		instance.name.put("Mina", 698523145);
		instance.name.put("Jennifer", 695654585);
		instance.name.put("Nour", 595632154);
		instance.name.put("Amine", 596321458);
		instance.name.put("Fathia", 1296325874);
		
		instance.name.remove("Nour");
		instance.name.remove("Julien");
		
		Enumeration e = instance.name.keys();
		
		while(e.hasMoreElements()){
			String k = (String) e.nextElement();
			System.out.println(k + " : " + instance.name.get(k));
		}
		
		//for(int i = 0 ; i < instance.name.size(); i++ ){
			//System.out.println("name : " + instance.name.keys() + " / ID : " + instance.name);	
		//}
		
	}

}
