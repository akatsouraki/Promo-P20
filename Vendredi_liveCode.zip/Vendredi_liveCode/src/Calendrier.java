import java.util.Hashtable;
import java.util.Scanner;


public class Calendrier {
	
public static void main (String [] args){
	Hashtable calendar = new Hashtable() ;
	
	calendar.put("January", 31);
	calendar.put("February",28);
	calendar.put("Mars", 31);
	calendar.put("April", 30);
	calendar.put("May", 31);
	calendar.put("June", 30);
	calendar.put("July", 31);
	calendar.put("August", 31);
	calendar.put("September", 30);
	calendar.put("Octobre", 31);
	calendar.put("November", 30);
	calendar.put("December", 31);
	
	System.out.println("Choose a month:");
	Scanner sc = new Scanner(System.in);
	String month = sc.nextLine() ;
	System.out.print(month + "is a month with " + calendar.get(month)+ " days");
}

}
