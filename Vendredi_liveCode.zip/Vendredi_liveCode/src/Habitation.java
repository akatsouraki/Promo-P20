
public class Habitation {
	private String proprietaire;
	private String adresse;
	private double surface;
	
	public Habitation(String proprietaire, String adresse, double surface) {
		this.proprietaire = proprietaire;
		this.adresse = adresse;
		this.surface = surface;
	}
	
	public void Affiche() {
		System.out.println("Proprietaire : "+this.proprietaire+", adresse : "+this.adresse+", surface :"+this.surface);
		
	}
	
	public double Impot() {
		double impot = 20*this.surface;
		return impot;
	}

	public static void main(String[] args) {
		
		Habitation maison = new Habitation("Steve", "2 rue des Sangliers 75016 PARIS", 155.00);
		maison.Affiche();
		System.out.print("Merci de payer : "+maison.Impot()+"$");
		
	}

}
