
public class Calcul {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int i = 1 ; 
    int sum = 0  ;
    
    for(i = 1 ; i <= 100 ; i ++){
    	sum = sum + i ;
    }
    
System.out.println("la sum est : " + sum); 
	}

}
