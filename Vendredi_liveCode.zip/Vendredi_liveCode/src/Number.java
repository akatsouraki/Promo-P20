import java.util.Scanner;
public class Number {

	static double numb;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner nb = new Scanner(System.in); 
System.out.println("entre un nombre");
numb = nb.nextDouble();
if(numb < 0){
	System.out.println("negatif");
}
else if (numb == 0){
	System.out.println("egal a zero");
}
else  {
	System.out.println("positif");
}

		
	
	double number = Math.abs(numb);
	if( number < 1){
		System.out.println("petit");
		}
	if( number > 1000000){
		System.out.println("grand");
	}
	
	}
}
