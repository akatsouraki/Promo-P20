import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Calculatrice extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculatrice frame = new Calculatrice();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Calculatrice() {
		setTitle("CALCULATRICE");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("NUMERO 1");
		lblNewLabel.setBounds(34, 41, 79, 24);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(109, 43, 266, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		
		textField_1 = new JTextField();
		textField_1.setBounds(110, 76, 266, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		
		final JLabel lblTotal = new JLabel("total");
		lblTotal.setBounds(166, 215, 124, 35);
		contentPane.add(lblTotal);
		
		JButton button = new JButton("+");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int n1 = Integer.parseInt(textField.getText());
				int n2 = Integer.parseInt(textField_1.getText());
				int total = n1 + n2;
				
				lblTotal.setText(String.valueOf(total));
			}
		});
		button.setBounds(73, 119, 45, 23);
		contentPane.add(button);
		
		JButton btnNewButton = new JButton("-");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int n1 = Integer.parseInt(textField.getText());
				int n2 = Integer.parseInt(textField_1.getText());
				int total = n1 - n2;
				
				lblTotal.setText(String.valueOf(total));
			}
		});
		btnNewButton.setBounds(145, 119, 51, 23);
		contentPane.add(btnNewButton);

		
		JButton button_1 = new JButton("*");
		button_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int n1 = Integer.parseInt(textField.getText());
				int n2 = Integer.parseInt(textField_1.getText());
				int total = n1 * n2;
				
				lblTotal.setText(String.valueOf(total));
			}
		});
		button_1.setBounds(224, 119, 51, 23);
		contentPane.add(button_1);
		
		JLabel lblNewLabel_1 = new JLabel("NUMERO 2");
		lblNewLabel_1.setBounds(34, 79, 66, 14);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_1 = new JButton("/");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int n1 = Integer.parseInt(textField.getText());
				int n2 = Integer.parseInt(textField_1.getText());
				int total = n1 / n2;
				
				lblTotal.setText(String.valueOf(total));
			}
		});
		btnNewButton_1.setBounds(306, 119, 57, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_3 = new JButton("CLEAR");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String s = "";
				lblTotal.setText(s);
				textField.setText(s);
				textField_1.setText(s);
				
				
			}
		});
		btnNewButton_3.setBounds(175, 163, 89, 23);
		contentPane.add(btnNewButton_3);
	
	}
}
