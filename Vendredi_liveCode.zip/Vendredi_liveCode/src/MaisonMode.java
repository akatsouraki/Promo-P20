import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.ListIterator;


public class MaisonMode {
	
	String nameMaisomMode;
	int idMaisonMode = 5;
	Hashtable topModel = new Hashtable();

	public static void main(String[] args) {

		MaisonMode instance = new MaisonMode();
		
		instance.topModel.put("Gwen", 5);
		instance.topModel.put("Jenny", 5);
		instance.topModel.put("Amina", 5);
		instance.topModel.put("Hayat", 5);
		instance.topModel.put("Nawal", 5);
		
		List e = Collections.list(instance.topModel.keys());
		Collections.sort(e);
		ListIterator i = e.listIterator();
		while (i.hasNext())
		System.out.println("TopModel : " + i.next() + " / ID : " + instance.idMaisonMode);

	}

}
