import java.util.ArrayList;

// Creer une classe java permettant de representer un film avec des infos 
public class Cinema {

	static String nomFilm;
	static String dateSortie;
	static ArrayList acteurs = new ArrayList();
	static int rate;
	
	public static String getMonFilm(){
		return nomFilm;
	}
	
	public static void setMonFilm(String film){
		nomFilm = film;
	}
	
	public static String getDateSortie(){
		return dateSortie;
	}
	
	public static void setDateSortie(String sortie){
		dateSortie = sortie;
	}
	
	public static ArrayList getActeurs(){
		return acteurs;
	}
	
	public static void setActeurs(ArrayList acteur){
		acteurs = acteur;
	}
	
	public static int getRate(){
		return rate;
	}
	
	public static void setRate(int rates){
		rate = rates;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub	
		setMonFilm("Pokemon le film");
		String f = getMonFilm();
		System.out.println(f);
	}

}
